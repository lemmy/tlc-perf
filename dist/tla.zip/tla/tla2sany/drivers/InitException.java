// Copyright (c) 2003 Compaq Corporation.  All rights reserved.
package tla2sany.drivers;

public class InitException extends Exception {}
