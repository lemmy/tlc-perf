// Copyright (c) 2003 Compaq Corporation.  All rights reserved.
// jcg wrote this.
// last revised February 1st 2000

package tla2sany.st;

public interface ParseErrors {
  public  ParseError[] errors();
}
