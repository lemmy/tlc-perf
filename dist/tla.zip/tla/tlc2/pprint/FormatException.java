// Copyright (c) 2003 Compaq Corporation.  All rights reserved.
// Last modified on Mon 30 Apr 2007 at  9:20:50 PST by lamport
//      modified on Fri Jun 11 17:50:09 PDT 1999 by yuanyu
//      modified on Thu Jun 10 14:52:19 EDT 1999 by tuttle

package tlc2.pprint;

public class FormatException extends Exception {

  FormatException(String s) {
    super(s);
  }

}
