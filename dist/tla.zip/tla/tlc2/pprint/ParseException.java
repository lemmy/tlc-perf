// Copyright (c) 2003 Compaq Corporation.  All rights reserved.
// Last modified on Mon 30 Apr 2007 at  9:21:08 PST by lamport
//      modified on Fri Jun 11 17:52:39 PDT 1999 by yuanyu
//      modified on Thu Jun 10 11:00:01 EDT 1999 by tuttle

package tlc2.pprint;

public class ParseException extends Exception {

  ParseException(String s) {
    super(s);
  }

}
