package pcal.exception;

/**
 * @author Simon Zambrovski
 * @version $Id: StringVectorToFileException.java 12768 2009-02-14 01:05:48Z simonzam $
 */
public class StringVectorToFileException extends UnrecoverableException
{

    /**
     * @param string
     */
    public StringVectorToFileException(String string)
    {
        super(string);
    }

}
