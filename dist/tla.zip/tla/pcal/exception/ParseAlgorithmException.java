package pcal.exception;

import pcal.AST;

/**
 * @author Simon Zambrovski
 * @version $Id: ParseAlgorithmException.java 12768 2009-02-14 01:05:48Z simonzam $
 */
public class ParseAlgorithmException extends UnrecoverablePositionedException
{

    /**
     * @param message
     */
    public ParseAlgorithmException(String message)
    {
        super(message);
    }

    /**
     * @param string
     * @param elementAt
     */
    public ParseAlgorithmException(String message, AST elementAt)
    {
        super(message, elementAt);
    }
}
