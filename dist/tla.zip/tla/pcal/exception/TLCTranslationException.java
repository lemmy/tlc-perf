package pcal.exception;

/**
 * @author Simon Zambrovski
 * @version $Id: TLCTranslationException.java 12768 2009-02-14 01:05:48Z simonzam $
 */
public class TLCTranslationException extends UnrecoverableException
{
    public TLCTranslationException(String message)
    {
        super(message);
    }
}
