package pcal.exception;

/**
 * @author Simon Zambrovski
 * @version $Id$
 */
public class UnrecoverableException extends Throwable
{
    public UnrecoverableException(String message)
    {
        super(message);
    }
}
