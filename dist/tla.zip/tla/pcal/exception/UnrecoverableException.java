package pcal.exception;

/**
 * @author Simon Zambrovski
 * @version $Id: UnrecoverableException.java 12768 2009-02-14 01:05:48Z simonzam $
 */
public class UnrecoverableException extends Throwable
{
    public UnrecoverableException(String message)
    {
        super(message);
    }
}
