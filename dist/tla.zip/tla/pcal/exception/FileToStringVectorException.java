package pcal.exception;

/**
 * @author Simon Zambrovski
 * @version $Id: FileToStringVectorException.java 12768 2009-02-14 01:05:48Z simonzam $
 */
public class FileToStringVectorException extends UnrecoverableException
{

    /**
     * @param string
     */
    public FileToStringVectorException(String string)
    {
        super(string);
    }

}
